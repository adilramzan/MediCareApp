package com.adilramzan.medicare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.adilramzan.medicare.databinding.ActivityGuestBinding;

public class GuestActivity extends AppCompatActivity {

    ActivityGuestBinding binding;
    NotificationManagerCompat notificationManagerCompat;
    Notification notification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityGuestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();

        //push notification code

        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.O){
            NotificationChannel channel=new NotificationChannel("myCh","My Channel", NotificationManager.IMPORTANCE_DEFAULT);

            NotificationManager manager=getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,"myCh")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("24*7 Medicare")
                .setContentText("Hi! welcome to Medicare health app");

        notification = builder.build();

        notificationManagerCompat = NotificationManagerCompat.from(this);

        //back button to splash activity
        binding.btnGABack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(GuestActivity.this,SplashScreen.class));
            }
        });

        //towards register activity
        binding.btnGAReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(GuestActivity.this,RegisterActivity.class));
            }
        });
    }

    public void push(View view) {
        notificationManagerCompat.notify(1,notification);
    }
}